<a href="#" class="scrollup" style="display: none;"><i class="ion-ios-arrow-up"></i></a>

<!-- Latest jQuery -->
<script src="{{ asset('public/front_asset/js/jquery-1.12.4.min.js')}}"></script>
<!-- jquery-ui -->
<script src="{{ asset('public/front_asset/js/jquery-ui.js')}}"></script>
<!-- popper min js -->
<script src="{{ asset('public/front_asset/js/popper.min.js')}}"></script>
<!-- Latest compiled and minified Bootstrap -->
<script src="{{ asset('public/front_asset/bootstrap/js/bootstrap.min.js')}}"></script>
<!-- owl-carousel min js  -->
<script src="{{ asset('public/front_asset/owlcarousel/js/owl.carousel.min.js')}}"></script>
<!-- magnific-popup min js  -->
<script src="{{ asset('public/front_asset/js/magnific-popup.min.js')}}"></script>
<!-- waypoints min js  -->
<script src="{{ asset('public/front_asset/js/waypoints.min.js')}}"></script>
<!-- parallax js  -->
<script src="{{ asset('public/front_asset/js/parallax.js')}}"></script>
<!-- jquery dd js  -->
<script src="{{ asset('public/front_asset/js/jquery.dd.min.js')}}"></script>
<!-- countdown js  -->
<script src="{{ asset('public/front_asset/js/jquery.countdown.min.js')}}"></script>
<!-- jquery.counterup.min js -->
<script src="{{ asset('public/front_asset/js/jquery.counterup.min.js')}}"></script>
<!-- jquery.parallax-scroll js -->
<script src="{{ asset('public/front_asset/js/jquery.parallax-scroll.js')}}"></script>
<!-- elevatezoom js -->
<script src='{{ asset('public/front_asset/js/jquery.elevatezoom.js')}}'></script>
<!-- fit video  -->
<script src="{{ asset('public/front_asset/js/jquery.fitvids.js')}}"></script>
<!-- imagesloaded js -->
<script src="{{ asset('public/front_asset/js/imagesloaded.pkgd.min.js')}}"></script>
<!-- isotope min js -->
<script src="{{ asset('public/front_asset/js/isotope.min.js')}}"></script>
<!-- cookie js -->
<script src="{{ asset('public/front_asset/js/js.cookie.js')}}"></script>
<!-- scripts js -->
<script src="{{ asset('public/front_asset/js/scripts.js')}}"></script>

</body>
</html>
