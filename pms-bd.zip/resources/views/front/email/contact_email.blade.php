<p>Hellow, This is {{$data['name']}}</p>
<p>{{$data['message']}}</p>
<p>Mobile: {{$data['phone']}}</p>