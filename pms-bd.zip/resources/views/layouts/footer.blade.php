  <footer class="main-footer">
    <strong>Develop By <a href="https://www.faisalrobin.com/">Faisal Robin</a>.</strong>
    <div class="float-right d-none d-sm-inline-block">
{{--      <b>Version</b> 3.0.5--}}
    </div>
  </footer>
